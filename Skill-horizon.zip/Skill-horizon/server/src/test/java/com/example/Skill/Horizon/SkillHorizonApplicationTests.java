package com.example.Skill.Horizon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillHorizonApplicationTests {

	@Test
	void contextLoads() {
	}

}
