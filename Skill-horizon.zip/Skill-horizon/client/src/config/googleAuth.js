// This Client ID will work for any Google user worldwide
export const GOOGLE_CLIENT_ID = "362891306384-j11idcm1ket8ri8js6nartfu5ukg671o.apps.googleusercontent.com";
export const GOOGLE_REDIRECT_URI = "http://localhost:8080/login/oauth2/code/google"; 